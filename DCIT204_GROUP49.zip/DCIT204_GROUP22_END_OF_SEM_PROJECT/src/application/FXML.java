package application;

public @interface FXML {
}
