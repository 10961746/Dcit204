package application;

import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

import Algorithms.Data;
import Algorithms.DjikstraAlgo;
import Algorithms.Utilities;
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

public class Main extends Application implements Initializable {

	@FXML
	private ComboBox<String> where_from, where_to;

	@FXML
	private Button view_complete_map;

	private final ArrayList<String> locations = new ArrayList<String>();

	// -- start for application
	@Override
	public void start(Stage stage) {
		// TODO Auto-generated method stub

		try {
			Parent root = FXMLLoader.load(getClass().getResource("Main.fxml"));
			Scene scene = new Scene(root);
			scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());

			stage.setTitle("DCIT204-DATA STRUCTURES AND ALGORITHM FINAL PROJECT");
			stage.setResizable(false);

			stage.setScene(scene);
			stage.show();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void switchToMap(ActionEvent event) {

		Parent parent = FXMLLoader.load(getClass().getResource("Map.fxml"));

		Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
		Scene scene = new Scene(parent, Color.AQUAMARINE);

		scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());

		stage.setTitle("DCTI204-VIEW COMPLETE MAP");
		stage.setResizable(false);

		stage.setScene(scene);
		stage.show();
	}

	public static void main(String[] arr) {
		launch(arr);
	}

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		// TODO Auto-generated method stub

		// -- populating array with values
		String[] location = { "Great Hall", "Convocation Group Of Building", "Legon Hall", "Legon Hall Annex A,B,C",
				"Athletic Oval", "Central Cafetaria", "Akuafo Hall", "Mensah Sarbah Hall", "Bush Canteen",
				"Night Market", "Volta Hall", "UGCS", "UGBS", "Balme Library", "School Of Performing Art", "Gate"

		};

		for (int x = 0; x < location.length; x++) {
			locations.add(location[x]);
		}

		where_from.setItems(FXCollections.observableArrayList(locations));
		where_to.setItems(FXCollections.observableArrayList(locations));

		// --calculating the best route of two distances using the Djisktra's Algorithm
		DjikstraAlgo algo = new DjikstraAlgo();
		int[] BEST_ROUTE = algo.IMPLEMENT(Data.EDGES, Data.VERTICES, Data.DISTANCES, Integer.getInteger(where_from.getId()),
				Integer.getInteger(where_to.getId()));

		System.out.println("Best Route to take is \n===============================");
		Utilities.PrintData(BEST_ROUTE);

		// --left to route location on the map

	}

}
