package application;

public interface Initializable {
}
