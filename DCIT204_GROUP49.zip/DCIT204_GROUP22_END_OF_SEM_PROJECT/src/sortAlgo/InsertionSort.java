package sortAlgo;

/**
 *With insertion sort, each element is sorted individually
 *if its place in the list is found, all other members go down
 *
 */
public class InsertionSort {


	public double[] insertSort(double[] array, boolean ascending) {
		for(int x=0; x<array.length; x++) {
			for(int y=0; y<array.length;y++) {
				if(y+1<array.length){

					//-- first find the smallest value
					double prev = array[x];
					double now  = array[y];

					//--swapping elements descending
					if(!ascending) {
						if(prev>now) {
							array[x] = now;
							array[y] = prev;
						}
					}


					//-- swapping elements ascending
					if(ascending) {
						if(prev<now) {
							array[x] = now;
							array[y] = prev;
						}
					}



				}
			}
		}

		return array;
	}

	public int[] insertSort(int[] array, boolean ascending) {
		for(int x=0; x<array.length; x++) {
			for(int y=0; y<array.length;y++) {
				if(y+1<array.length){

					//-- first find the smallest value
					int prev = array[x];
					int now  = array[y];

					//--swapping elements descending
					if(!ascending) {
						if(prev>now) {
							array[x] = now;
							array[y] = prev;
						}
					}


					//-- swapping elements ascending
					if(ascending) {
						if(prev<now) {
							array[x] = now;
							array[y] = prev;
						}
					}



				}
			}
		}

		return array;
	}
}
