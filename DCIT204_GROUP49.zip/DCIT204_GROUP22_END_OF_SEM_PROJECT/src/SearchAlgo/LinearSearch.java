package SearchAlgo;

public class LinearSearch {

	public int linSearch(double[] array,double key) {
		//--returns index if key is found
		int index = -1;
		
		for(int x=0; x<array.length; x++) {
			if(array[x] == key) {
				//-- returns the current x value if the key matches a value
				index = x;
			}
		}
		
		return (int)index;
	}
	
	public int linSearch(int[] array,double key) {
		//--returns index if key is found
		int index = -1;
		
		for(int x=0; x<array.length; x++) {
			if(array[x] == key) {
				//-- returns the current x value if the key matches a value
				index = x;
			}
		}
		
		return (int)index;
	}

}
