module HelloFx {
	requires javafx.controls;
	requires javafx.graphics;
	requires javafx.fxml;
	requires javafx.base;
    requires android;

    opens application to javafx.graphics, javafx.fxml;
}
