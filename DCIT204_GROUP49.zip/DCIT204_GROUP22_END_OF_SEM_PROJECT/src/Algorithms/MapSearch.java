package Algorithms;

/***
 *
 * @author DCIT204 - DATA STRUCTURES AND ALGORITHM
 * This class algorithm performs a string search from a
 * suggestion of all locations on the map
 *
 */

public class MapSearch {

	// we return -1 if key is not found, else we return the key

	public int search(String[] arr, String key) {

		// --integrating key into characters and placing in character array
		int searchVal = -1;
		char[] characters = new char[key.length()];

		for (int a = 0; a < key.length(); a++) {
			characters[a] = key.charAt(a);
		}

		boolean searchFound = false, keyfound = false;
		int iterator = 0;

		for (int x = 0; x < arr.length; x++) {
			String location = arr[x].toLowerCase();

			//--breaking out of loop if key is found
			if(keyfound){break;}

			for (int y = 0; y < location.length(); y++) {
				keyfound = (iterator + 1) >= (characters.length) && searchFound;

				if (keyfound) {searchVal = x;break;}

				if (characters[iterator] == location.charAt(y)) {
					searchFound = true;iterator++;
				} else {
					searchFound = false;iterator = 0;
				}
			}

			iterator = 0;
		}

		return searchVal-1;
	}

}
