package Algorithms;


import sortAlgo.InsertionSort;

public class DjikstraAlgo {

	private int total_weight = 0;

	public int GetTotalWeight() {
		return total_weight;
	}

	public int[] IMPLEMENT(int[][] GRAPH, int[] VERTEX, int[][] WEIGHT,  final int source, final int destination) {

		// -- keeps the 3 routes of the destination with routeA as the best
		int[] routeA = new int[GRAPH.length];
		int[] routeB = new int[GRAPH.length];
		int[] routeC = new int[GRAPH.length];

		// -- checks if destination is at the left or right of the tree
		boolean firstloop = false, checkLorR = false, left = true;
		int destInt = 0, nextnode = 0;
		int[] destPlaces = new int[VERTEX.length - 1];

		// getting the various routes to the destination
		for (int x = 0; x < routeA.length; x++) {
			for (int y = 0; y < GRAPH[x].length; y++) {
				if (GRAPH[x][y] == destination) {
					destPlaces[destInt] = x;
					destInt++;
				}
			}
		}

		// -- check if the key is on left or right
		if (!checkLorR) {
			left = source > destination;
		}

		// -- performing djistra's algorithm
		int counter = 0;
		int totalweight = 0;
		for (int x = source - 1; x < destination - 1; x++) {
			int smallest = 0, indexSmall = 0;
			int[] dummy = new int[WEIGHT[x].length];
			for (int b = 0; b < WEIGHT[x].length; b++) {
				dummy[b] = nextnode + WEIGHT[x][b];
			}
			InsertionSort sort = new InsertionSort();

			smallest = (sort.insertSort(dummy, true))[0];

			for (int a = 0; a < WEIGHT[x].length; a++) {
				if (smallest == WEIGHT[x][a]) {
					indexSmall = a;
					break;
				}
				nextnode = smallest;

			}

			// --saving value of graph into array and returning it
			totalweight += smallest;
			if (smallest > 0) {
				routeA[counter] = GRAPH[x][indexSmall];
				counter++;
			}
			if (routeA[counter] == destination) {
				break;
			}

			/* ===================================================================== */
		}
		total_weight = totalweight;
		return routeA;
	}

}
