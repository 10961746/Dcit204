package Algorithms;

/***
 * 
 * @author DCIT204 - DATA STRUCTURES AND ALGORITHM END OF SEMESTER PROJECT
 * Utilities Class for Basic Requirements
 *
 */

public class Utilities {
	public static void PrintData(String[] arr) {
		for (int x = 0; x < arr.length; x++) {
			System.out.print(arr[x] + ", ");
		}
	}

	public static void PrintData(char[] arr) {
		for (int x = 0; x < arr.length; x++) {
			System.out.print(arr[x] + ", ");
		}
	}

	public static void PrintData(int[] arr) {
		for (int x = 0; x < arr.length; x++) {
			System.out.print(arr[x] + ", ");
		}
	}

	public static void PrintData(double[] arr) {
		for (int x = 0; x < arr.length; x++) {
			System.out.print(arr[x] + ", ");
		}
	}
}
