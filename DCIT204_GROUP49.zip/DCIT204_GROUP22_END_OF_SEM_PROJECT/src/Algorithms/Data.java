package Algorithms;

/***
 * 
 * @author DCIT204 - DATA STRUCTURES AND ALGORITHM This class basically contains
 *         all the necessary data needed by the algorithm
 *
 */

public class Data {
	public static java.lang.String[] LOCATIONS = { "Great Hall", "Convocation Group Of Building", "Legon Hall",
			"Legon Hall Annex A,B,C", "Athletic Oval", "Central Cafetaria", "Akuafo Hall", "Mensah Sarbah Hall",
			"Bush Canteen", "Night Market", "Volta Hall", "UGCS", "UGBS", "Balme Library", "School Of Performing Art",
			"Gate"

	};
	public static final int[] VERTICES = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15 };

	public static final int[][] EDGES = { { 2 }, { 3, 4 }, { 5, 6, 12 }, { 12, 13 }, { 0 }, { 7, 8 }, { 9, 10 }, { 0 },
			{ 11 }, { 0 }, { 8, 14 }, { 14 }, { 15 }, { 11 } };

	public static final int[][] DISTANCES = { { 300 }, { 1100, 1200 }, { 240, 700, 600 }, { 480, 190 }, { 0 }, { 200, 500 },
			{ 200, 190 }, { 0 }, { 500 }, { 0 }, { 480, 190 }, { 400 }, { 200 }, { 560 }, };

	public static java.lang.String[] LANDMARKS = { "Great Hall", "Convocation Group Of Building", "Legon Hall",
			"Legon Hall Annex A,B,C", "Athletic Oval", "Central Cafetaria", "Akuafo Hall", "Mensah Sarbah Hall",
			"Bush Canteen", "Night Market", "Volta Hall", "UGCS", "UGBS", "Balme Library", "School Of Performing Art",
			"Gate" };
}
